# Driver Drowsiness & Distraction Detection System
### Team 3 | Automotive Safety / ADAS

---

## Project Overview

An in-cabin driver monitoring system that detects:

| Detection | Method | Metric |
|-----------|--------|--------|
| Eye closure / drowsiness | MediaPipe EAR | Eye Aspect Ratio < 0.25 for 15+ frames |
| Yawning | MediaPipe MAR | Mouth Aspect Ratio > 0.60 for 20+ frames |
| Head pose (distraction) | solvePnP + 6-point | Pitch > 20° or Yaw > 30° |
| Phone usage | YOLOv8n (COCO fine-tuned) | Confidence > 0.45 |

---

## Repository Structure

```
driver_monitoring/
├── notebooks/
│   ├── 01_dataset_setup.ipynb        ← Dataset download, EDA, preprocessing
│   └── 02_model_and_inference.ipynb  ← Inference pipeline, evaluation, YOLO training
├── src/
│   ├── detectors.py    ← EAR, MAR, HeadPose, Phone detector classes
│   └── alert_engine.py ← Fusion engine, audio alert, HUD overlay
├── requirements.txt
└── README.md
```

---

## Datasets

| Dataset | Task | Link |
|---------|------|------|
| MRL Eye Dataset | Eye open/closed | [Kaggle](https://www.kaggle.com/datasets/imadeddinedjerarda/mrl-eye-dataset) |
| Yawning Detection Dataset | Yawn classification | [Kaggle](https://www.kaggle.com/datasets/davidvazquezcic/yawn-eye-dataset-new) |
| Driver Drowsiness Dataset | End-to-end drowsy/alert | [Kaggle](https://www.kaggle.com/datasets/ismailnasri20/driver-drowsiness-dataset) |
| Roboflow Cell Phones | Phone detection (YOLO) | [Roboflow](https://universe.roboflow.com/roboflow-100/cell-phones-la4oe) |

---

## Quick Start (Google Colab)

1. Upload project to Google Drive or clone from GitHub
2. Open `notebooks/01_dataset_setup.ipynb` and run all cells
3. Upload `kaggle.json` when prompted to download datasets
4. Open `notebooks/02_model_and_inference.ipynb`
5. Upload a test video and run inference pipeline

---

## Model Architecture

### Landmark-based modules (EAR, MAR, Head Pose)
- **Input**: 478-point MediaPipe FaceMesh landmarks
- **EAR**: 6 eye landmarks → aspect ratio → threshold + temporal filter
- **MAR**: 10 mouth landmarks → aspect ratio → threshold + temporal filter
- **Head Pose**: 6 canonical 3D-2D point correspondences → `cv2.solvePnP` → Euler angles

### Phone detection (YOLOv8n)
- Pretrained on MS-COCO (class 67 = cell phone)
- Fine-tuned on Roboflow phone-in-car dataset
- Exported to ONNX and TFLite for deployment

### Alert Fusion
- Weighted combination of four signals (EAR 35%, Head 25%, MAR 20%, Phone 20%)
- Three alert levels: Safe (0), Warning (1), Critical (2)
- Temporal smoothing to avoid false positives from brief occlusions

---

## Evaluation Metrics

- **EAR/MAR modules**: Precision, Recall, F1 per threshold (ablation study)
- **Head pose**: Mean Absolute Error on pitch/yaw vs. annotated labels
- **Phone detection**: mAP@0.5, mAP@0.5:0.95
- **System-level**: Confusion matrix (Safe/Warning/Critical), FPS on CPU/GPU
- **Inference speed**: Mean latency (ms), P95 latency, FPS benchmark

---

## Deployment

```bash
# ONNX export
yolo export model=best.pt format=onnx opset=17

# TFLite export (for Raspberry Pi / Jetson Nano)
yolo export model=best.pt format=tflite

# Inference speed target
# CPU (i5/i7): ~15-20 FPS
# GPU (Colab T4): ~45-60 FPS
```

---

## Industry Relevance

Target companies: Tata Elxsi, Mahindra & Mahindra (ADAS), Continental Automotive India

This system addresses ADAS driver monitoring requirements under ISO 26262 and NCAP 2026 mandates requiring factory-fitted drowsiness detection in new vehicles.
