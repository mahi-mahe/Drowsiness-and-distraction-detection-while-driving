"""
driver_monitoring/src/alert_engine.py

Alert fusion and decision engine.
Combines EAR, MAR, head pose and phone signals into a single alert level.

Alert levels:
  0 — Safe        (all signals normal)
  1 — Warning     (single mild trigger; yellow)
  2 — Critical    (multiple or severe triggers; red + sound)
"""

import time
import threading
from dataclasses import dataclass
from typing import List, Optional
from src.detectors import DetectionResult


@dataclass
class AlertConfig:
    # EAR
    ear_warning_frames:  int   = 15    # ~ 0.5s at 30fps
    ear_critical_frames: int   = 45    # ~ 1.5s
    # MAR
    mar_warning_frames:  int   = 20
    mar_critical_frames: int   = 50
    # Head pose
    head_warning_frames:  int  = 10
    head_critical_frames: int  = 30
    # Phone
    phone_warning_conf:   float = 0.45
    phone_critical_conf:  float = 0.70
    # Cooldown between same alert (seconds)
    alert_cooldown: float = 3.0


class AlertEngine:
    """
    Stateful alert fusion engine.

    Maintains a rolling score per modality and combines them
    using a configurable weighted sum to determine alert level.
    """

    WEIGHTS = {
        'eyes':  0.35,
        'yawn':  0.20,
        'head':  0.25,
        'phone': 0.20,
    }

    def __init__(self, config: Optional[AlertConfig] = None):
        self.cfg = config or AlertConfig()
        self._last_alert_time: dict = {}
        self._alert_count: dict = {}

    def evaluate(self, result: DetectionResult) -> int:
        """
        Returns alert level: 0, 1, or 2.
        Also populates result.alert_level and result.alert_reason.
        """
        scores = {}

        # ── Eyes ──────────────────────────────────
        if result.eye_closed_frames >= self.cfg.ear_critical_frames:
            scores['eyes'] = 2
        elif result.eye_closed_frames >= self.cfg.ear_warning_frames:
            scores['eyes'] = 1
        else:
            scores['eyes'] = 0

        # ── Yawn ──────────────────────────────────
        if result.yawn_frames >= self.cfg.mar_critical_frames:
            scores['yawn'] = 2
        elif result.yawn_frames >= self.cfg.mar_warning_frames:
            scores['yawn'] = 1
        else:
            scores['yawn'] = 0

        # ── Head pose ─────────────────────────────
        if result.head_distracted:
            scores['head'] = 2 if result.yaw_frames >= self.cfg.head_critical_frames else 1
        else:
            scores['head'] = 0

        # ── Phone ─────────────────────────────────
        if result.phone_detected:
            if result.phone_confidence >= self.cfg.phone_critical_conf:
                scores['phone'] = 2
            else:
                scores['phone'] = 1
        else:
            scores['phone'] = 0

        # ── Weighted fusion ───────────────────────
        fused = sum(self.WEIGHTS[k] * scores[k] for k in scores)

        # Hard rule: any critical signal alone → at least warning
        any_critical = any(v == 2 for v in scores.values())
        active_count = sum(1 for v in scores.values() if v > 0)

        if fused >= 1.4 or (any_critical and active_count >= 2):
            level = 2
        elif fused >= 0.5 or any_critical:
            level = 1
        else:
            level = 0

        result.alert_level = level
        return level

    def should_alert(self, alert_type: str) -> bool:
        """Rate-limit repeated alerts of the same type."""
        now = time.time()
        last = self._last_alert_time.get(alert_type, 0)
        if now - last >= self.cfg.alert_cooldown:
            self._last_alert_time[alert_type] = now
            self._alert_count[alert_type] = self._alert_count.get(alert_type, 0) + 1
            return True
        return False

    def get_alert_summary(self) -> dict:
        return dict(self._alert_count)


class AudioAlert:
    """
    Non-blocking audio alert using pygame.
    Falls back to terminal beep if pygame unavailable.
    """

    def __init__(self):
        self._pygame_ok = False
        self._setup()

    def _setup(self):
        try:
            import pygame
            pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
            self._pygame = pygame
            self._pygame_ok = True
        except Exception:
            pass

    def _generate_beep(self, frequency: int, duration_ms: int, volume: float = 0.6):
        import numpy as np
        sample_rate = 22050
        n_samples = int(sample_rate * duration_ms / 1000)
        t = np.linspace(0, duration_ms / 1000, n_samples, False)
        wave = (np.sin(2 * np.pi * frequency * t) * volume * 32767).astype(np.int16)
        # Stereo
        stereo = np.column_stack([wave, wave])
        return self._pygame.sndarray.make_sound(stereo)

    def beep(self, level: int = 1):
        """level 1 = warning (500Hz), level 2 = critical (900Hz double)."""
        if not self._pygame_ok:
            print('\a', end='', flush=True)
            return

        def _play():
            if level == 1:
                s = self._generate_beep(500, 400, 0.4)
                s.play()
            else:
                s1 = self._generate_beep(900, 250, 0.7)
                s2 = self._generate_beep(700, 250, 0.7)
                s1.play()
                time.sleep(0.3)
                s2.play()

        threading.Thread(target=_play, daemon=True).start()


class OverlayRenderer:
    """
    Draws the HUD overlay on each video frame.
    Shows metrics, alert banner, and status indicators.
    """

    COLORS = {
        'safe':     (0, 200, 100),   # green
        'warning':  (0, 165, 255),   # orange
        'critical': (0, 0, 255),     # red
        'text':     (255, 255, 255),
        'bg':       (20, 20, 20),
    }

    LEVEL_LABELS = {0: 'SAFE', 1: 'WARNING', 2: 'CRITICAL'}

    def render(self, frame, result: DetectionResult):
        """Draw all HUD elements onto frame (in-place)."""
        h, w = frame.shape[:2]
        color = self.COLORS[['safe', 'warning', 'critical'][result.alert_level]]

        # ── Top panel ──────────────────────────────
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (w, 36), self.COLORS['bg'], -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

        # FPS
        cv2.putText(frame, f"FPS: {result.fps:.0f}", (10, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, self.COLORS['text'], 1)

        # Alert level badge
        label = self.LEVEL_LABELS[result.alert_level]
        cv2.putText(frame, label, (w // 2 - 50, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, color, 2)

        # ── Metrics sidebar ────────────────────────
        metrics = [
            f"EAR:   {result.ear:.3f}  {'CLOSED' if result.eye_closed else 'open'}",
            f"MAR:   {result.mar:.3f}  {'YAWN' if result.yawning else 'ok'}",
            f"Pitch: {result.pitch:+.1f}  Yaw: {result.yaw:+.1f}",
            f"Phone: {'YES' if result.phone_detected else 'no'}"
            + (f" {result.phone_confidence:.0%}" if result.phone_detected else ""),
        ]
        y0 = 60
        for i, txt in enumerate(metrics):
            c = color if i == 0 and result.eye_closed else self.COLORS['text']
            cv2.putText(frame, txt, (10, y0 + i * 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.52, c, 1)

        # ── Critical banner ────────────────────────
        if result.alert_level == 2:
            overlay2 = frame.copy()
            cv2.rectangle(overlay2, (0, h - 50), (w, h), (0, 0, 200), -1)
            cv2.addWeighted(overlay2, 0.55, frame, 0.45, 0, frame)
            reasons = ' | '.join(result.alert_reason[:3])
            cv2.putText(frame, f"ALERT: {reasons}", (10, h - 16),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        # ── Status dots (bottom-right) ─────────────
        indicators = [
            ('EYE', result.eye_closed,       (0, 0, 255) if result.eye_closed else (0, 200, 0)),
            ('YWN', result.yawning,          (0, 0, 255) if result.yawning    else (0, 200, 0)),
            ('HED', result.head_distracted,  (0, 165, 255) if result.head_distracted else (0, 200, 0)),
            ('PHN', result.phone_detected,   (0, 0, 255) if result.phone_detected   else (0, 200, 0)),
        ]
        for j, (lbl, active, dot_color) in enumerate(indicators):
            cx = w - 35
            cy = 60 + j * 30
            cv2.circle(frame, (cx, cy), 8, dot_color, -1)
            cv2.putText(frame, lbl, (cx - 30, cy + 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, self.COLORS['text'], 1)

        return frame
